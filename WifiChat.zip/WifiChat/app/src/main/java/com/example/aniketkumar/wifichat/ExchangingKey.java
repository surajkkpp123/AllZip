package com.example.aniketkumar.wifichat;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;


public class ExchangingKey extends AppCompatActivity {

    ProgressBar pubLoader,AESLoader;
    TextView pubStat,AESStat;
    PublicKey publicKey;
    String pubKey;
    int i=0;
    String clientADDr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exchanging_key);
        pubLoader=findViewById(R.id.pubLoader);
        AESLoader=findViewById(R.id.AESLoader);
        pubStat=findViewById(R.id.pubStat);
        AESStat=findViewById(R.id.AESStat);
        pubLoader.setVisibility(View.VISIBLE);
        AESLoader.setVisibility(View.VISIBLE);

            RSA rsa=new RSA();
            rsa.generateKey();
            RSA.MyPrivateKey=rsa.getPrivateKey();
            publicKey=rsa.getPublicKey();
            Log.e("TAGG","sent"+publicKey);
            byte[] publicKeyBytes = Base64.encode(publicKey.getEncoded(),Base64.DEFAULT);
            pubKey = new String(publicKeyBytes);
            if(!RSA.hostIP.equals("null"))
            {
                Toast.makeText(getApplicationContext(),"client Started ",Toast.LENGTH_LONG).show();
                new Client(pubKey).execute();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"server Started ",Toast.LENGTH_LONG).show();
                new PubServer().execute();
            }


        }

    public  class Client extends AsyncTask<String,String,String>
    {
        String str;
        public Client(String str)
        {
            this.str=str;
        }

        @Override
        protected String doInBackground(String... voids) {

            int port=8888;
            String ip;
                try{
                    if(RSA.hostIP.equals("null"))
                    {
                        ip=clientADDr;
                    }
                    else
                        ip=RSA.hostIP;

                Socket socket=new Socket(ip,port);
                DataOutputStream dos=new DataOutputStream(socket.getOutputStream());
                dos.writeUTF(str);
                dos.flush();
                dos.close();
                socket.close();
                return "a";
            } catch (IOException e) {
                Log.e("TAG","Public Key Sending Error"+e.getMessage());
                e.printStackTrace();
            }
            return "null";
        }

        @Override
        protected void onPostExecute(String s) {


            super.onPostExecute(s);
            pubStat.setVisibility(View.VISIBLE);
            pubLoader.setVisibility(View.GONE);
            if(s.equals("a")) {
               String str= pubStat.getText().toString();
                pubStat.setText(str+"\nKey Sended ");
                i++;
                if (i <=1) {
                    new PubServer().execute();
                }
            }
            else
            {
                String str= pubStat.getText().toString();
               pubStat.setText(str+"\nSending Error");
            }

        }
    }
    public  class PubServer extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {

                int port=8888;
                ServerSocket serverSocket = new ServerSocket(port);
                Log.d("TAG", "Server: Socket opened");
                Socket client = serverSocket.accept();
                clientADDr=client.getInetAddress().getHostAddress();

                Log.d("TAG", "Server: connection done");
                DataInputStream in = new DataInputStream(
                        new BufferedInputStream(client.getInputStream()));
                String str = in.readUTF();

                Log.e("TAGG", str);
                in.close();
                client.close();
                serverSocket.close();
                return str;

            } catch (IOException e) {
                Log.e("TAG", e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pubLoader.setVisibility(View.GONE);
            if(s!=null) {
                PublicKey publicKey=getKey(s);

                pubStat.setVisibility(View.VISIBLE);
                if(publicKey!=null)
                {
                    RSA.senderPublicKey=publicKey;
                    Log.e("tagg","revpub"+publicKey);
                    String str= pubStat.getText().toString();
                    pubStat.setText(str+"\nPublic Key Receive Successfully");
                    i++;
                    if(i<2) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        new Client(pubKey).execute();
                    }

                }
                else
                {
                    String str= pubStat.getText().toString();
                    pubStat.setText(str+"\nError in Receiving");
                }
            }


        }
    }
    public static PublicKey getKey(String key){
        try{
            byte[] byteKey = Base64.decode(key.getBytes(), Base64.DEFAULT);
            X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePublic(X509publicKey);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }





}
