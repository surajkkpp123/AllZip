package com.example.aniketkumar.wifichat;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import co.intentservice.chatui.ChatView;
import co.intentservice.chatui.models.ChatMessage;

public class Communication extends AppCompatActivity {

   public  ChatView chatView;

    String host;
    String ClientAddr="";
    int i;
    Socket socket;
    ServerSocket serverSocket;
    DataOutputStream dos=null;
    SecretKey secretKey;
    String EncyptedKey;
    int p=0;
    int j=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_communication1);
        Intent intent = getIntent();
        host=intent.getStringExtra("ip");
        i=intent.getIntExtra("server",0);
        ScheduledExecutorService scheduleTaskExecutor = Executors.newScheduledThreadPool(5);


        Log.e("TAG","ip"+host);
        if(i==0)
        RSA.hostIP=host;

        // This schedule a runnable task every 2 seconds
        if(i==1)
            scheduleTaskExecutor.scheduleAtFixedRate(new Runnable() {
                public void run() {
                    call();
                }
            }, 0, 2, TimeUnit.MINUTES);
        if(i==0)
            scheduleTaskExecutor.scheduleAtFixedRate(new Runnable() {
                public void run() {
                    call1();
                }
            }, 0, 3, TimeUnit.MINUTES);
        chatView =  findViewById(R.id.chat_view);
        chatView.setOnSentMessageListener(new ChatView.OnSentMessageListener()
        {
            @Override
            public boolean sendMessage(ChatMessage chatMessage){
                if(i==1)
                {
                    if(ClientAddr.equals(""))
                    {
                        Toast.makeText(getApplicationContext(),"Client Address null",Toast.LENGTH_LONG).show();
                        return false;
                    }
                }
                try {
                    if(serverSocket!=null)
                    serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if(j==0)
                {
                    Toast.makeText(getApplicationContext(),"Sending Key...",Toast.LENGTH_LONG).show();
                    if(EncyptedKey==null)
                    {
                        Toast.makeText(getApplicationContext(),"Encyprion error",Toast.LENGTH_LONG).show();
                        return false;
                    }
                    j=1;
                    new Client(EncyptedKey).execute();
                    chatView.addMessage(new ChatMessage("Key Sended",System.currentTimeMillis(), ChatMessage.Type.SENT));
                    return false;
                }
                String Encry=new Encryption("AES").encrypt(chatMessage.getMessage());
                chatView.addMessage(new ChatMessage(Encry,System.currentTimeMillis(), ChatMessage.Type.SENT,"Encrypted"));
                new Client(Encry).execute();
                return true;
            }
        });

        Encryption encryption=new Encryption("AES");
        encryption.generateKey();
        secretKey=Encryption.secretKey;

        byte[] secKeyBytes = Base64.encode(secretKey.getEncoded(),Base64.DEFAULT);
        String secKey = new String(secKeyBytes);
        Log.e("sent",""+secretKey);
        //encrypt the AES/DES using RSA
        RSA rsa=new RSA();
        EncyptedKey=rsa.encrypt(secKey);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    public void call()
    {
        if(i==1)
        {
            new FileServerAsyncTask().execute();
        }
    }
    public void call1()
    {

            Log.e("TAGG","Server 2 started Client Address Found");
            new FileServerAsyncTask2().execute();
    }
    public  class Client extends  AsyncTask<Void,Void,Void>
    {
        String str;
        public Client(String str)
        {   Log.e("TAG",str);
            this.str=str;
        }

        @Override
        protected Void doInBackground(Void... voids) {

            int port=8988;
            Log.e("TAG","i is "+i);
            try {
                if(i==1)
                {
                    host=ClientAddr;
                    Log.e("TAG",ClientAddr);
                    port=9000;

                }
              socket=new Socket(host,port);
               dos=new DataOutputStream(socket.getOutputStream());
                dos.writeUTF(str);
                dos.flush();
                dos.close();
                socket.close();
            } catch (IOException e) {
                Log.e("TAG","CLIENT ERROR"+e.getMessage());
                e.printStackTrace();
            }
            return null;
        }
    }
     public  class FileServerAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {

                int port=8988;
                 serverSocket = new ServerSocket(port);
                Log.d("TAG", "Server: Socket opened");
                Socket client = serverSocket.accept();
                ClientAddr=client.getInetAddress().getHostAddress();

                Log.d("TAG", "Server: connection done");
                DataInputStream in = new DataInputStream(
                        new BufferedInputStream(client.getInputStream()));
                    String str = in.readUTF();

                    Log.e("TAGG", str);
                 in.close();
                client.close();
                serverSocket.close();
                return str;

            } catch (IOException e) {
                Log.e("TAG", e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null) {
                if(p==0)
                {
                    String Sec=new RSA().decrypt(s);
                    if(Sec==null)
                    {
                     Toast.makeText(getApplicationContext(),"Decyption error ",Toast.LENGTH_LONG).show();
                    }
                    else {
                        byte[] decodedKey = Base64.decode(Sec.getBytes(), Base64.DEFAULT);
                        SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
                        Encryption.senderKey = originalKey;
                        p = 1;
                        ChatMessage chatMessage = new ChatMessage("Key Received Successfully1", System.currentTimeMillis(), ChatMessage.Type.RECEIVED);
                        chatView.addMessage(chatMessage);
                    }

                }
                else {
                    String en=new Encryption("AES").decrypt(s);
                    chatView.addMessage(new ChatMessage(s,System.currentTimeMillis(), ChatMessage.Type.RECEIVED,"Encrypted"));
                    ChatMessage chatMessage = new ChatMessage(en, System.currentTimeMillis(), ChatMessage.Type.RECEIVED);
                    chatView.addMessage(chatMessage);
                }
            }
            new FileServerAsyncTask().execute();

        }
    }


    public  class FileServerAsyncTask2 extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {

              int port=9000;

                serverSocket = new ServerSocket(port);
                Log.d("TAG", "Client Server: Socket opened");
                Socket client = serverSocket.accept();

                Log.d("TAG", "Server Client : connection done");
                DataInputStream in = new DataInputStream(
                        new BufferedInputStream(client.getInputStream()));
                String str = in.readUTF();

                Log.e("TAGG", str);
                in.close();
                client.close();
                serverSocket.close();
                return str;

            } catch (IOException e) {
                Log.e("TAG", e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null) {
                if(p==0)
                {
                    String Sec=new RSA().decrypt(s);
                    byte[] decodedKey = Base64.decode(Sec.getBytes(),Base64.DEFAULT);
                    SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
                    Encryption.senderKey=originalKey;
                    p=1;
                    ChatMessage chatMessage = new ChatMessage("Key Received Successfully", System.currentTimeMillis(), ChatMessage.Type.RECEIVED);
                    chatView.addMessage(chatMessage);

                }
                else {
                    String en=new Encryption("AES").decrypt(s);
                    chatView.addMessage(new ChatMessage(s,System.currentTimeMillis(), ChatMessage.Type.RECEIVED,"Encrypted"));
                    ChatMessage chatMessage = new ChatMessage(en, System.currentTimeMillis(), ChatMessage.Type.RECEIVED);
                    chatView.addMessage(chatMessage);
                }

            }
            new FileServerAsyncTask2().execute();

        }
    }

    public void startNewServerClient(View view)
    {
//        if(i==0)
//        new FileServerAsyncTask2().execute();
    }
}
