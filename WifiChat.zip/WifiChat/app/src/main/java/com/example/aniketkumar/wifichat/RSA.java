package com.example.aniketkumar.wifichat;

/**
 * Created by Aniket Kumar on 27-Oct-18.
 */

import android.util.Base64;
import android.util.Log;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.*;
import java.security.PublicKey;
import java.security.Security;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import de.flexiprovider.core.FlexiCoreProvider;

public class RSA {
    public PrivateKey privateKey;
    public PublicKey publicKey;
    public static PublicKey senderPublicKey=null;
    public static PrivateKey MyPrivateKey;
    public static String hostIP="null";
    public RSA(){

    }
    public void generateKey()
    {
        Security.addProvider(new FlexiCoreProvider());
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(1024);
            KeyPair keyPair=kpg.generateKeyPair();
            this.privateKey = keyPair.getPrivate();
            this.publicKey = keyPair.getPublic();
        }catch (Exception io)
        {
            Log.e("TAG","Exception "+io.getMessage());
        }
    }
    public PrivateKey getPrivateKey()
    {
        return this.privateKey;
    }
    public PublicKey getPublicKey()
    {
        return this.publicKey;
    }
    public String encrypt(String data){

        try {
            Cipher c = Cipher.getInstance("RSA");
            c.init(Cipher.ENCRYPT_MODE,senderPublicKey);
            byte[] encVal = c.doFinal(data.getBytes());
            return android.util.Base64.encodeToString(encVal, Base64.DEFAULT);
        } catch (NoSuchAlgorithmException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException | NoSuchPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String decrypt(String enc){
        try {
            Cipher c = Cipher.getInstance("RSA");
            c.init(Cipher.DECRYPT_MODE,MyPrivateKey );
            Log.e("TAGGG","privatekey");
            byte[] decodedValue =android.util.Base64.decode(enc,Base64.DEFAULT);
            byte[] decVal = c.doFinal(decodedValue);
            return new String(decVal);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            Log.e("TAGGG",e.getMessage());
        }
        return null;
    }


}
