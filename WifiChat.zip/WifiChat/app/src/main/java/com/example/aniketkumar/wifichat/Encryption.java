package com.example.aniketkumar.wifichat;

/**
 * Created by Aniket Kumar on 27-Oct-18.
 */
import android.util.Log;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import de.flexiprovider.core.FlexiCoreProvider;
public class Encryption {
    public String Algo;
    public static  SecretKey secretKey;
    Cipher cipher;
    public static SecretKey senderKey=null;

    public Encryption(String Algo)
    {
        this.Algo=Algo;
        Security.addProvider(new FlexiCoreProvider());
        try {
            cipher = Cipher.getInstance(Algo);
        }
        catch (Exception e)
        {
            Log.e("TAG",e.getMessage());
        }

    }
    public void generateKey()
    {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(Algo);
            secretKey= keyGen.generateKey();
        }
        catch (Exception e)
        {
            Log.e("TAG","In Encryption "+e.getMessage());
        }
    }
    public SecretKey getSecretKey()
    {
        return this.secretKey;
    }
    public String encrypt(String data){

        try {
            Cipher c = Cipher.getInstance(Algo);
            c.init(Cipher.ENCRYPT_MODE,secretKey);
            byte[] encVal = c.doFinal(data.getBytes());
            return android.util.Base64.encodeToString(encVal,1);
        } catch (NoSuchAlgorithmException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException | NoSuchPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String decrypt(String enc){
        try {
            Cipher c = Cipher.getInstance(Algo);
            c.init(Cipher.DECRYPT_MODE,senderKey);
            byte[] decodedValue =android.util.Base64.decode(enc,1);
            byte[] decVal = c.doFinal(decodedValue);
            return new String(decVal);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            e.printStackTrace();
        }
        return null;
    }

}
